    <!-- Main jumbotron for a primary marketing message or call to action -->
    <div class="pt-3">
      <div class="container">
<hr>
      	<div class="row pt-5 pb-4">
        	<div class="col">
            <p>Generador QR Avanzado</p>
          </div>
        </div>
<hr>
        
      </div>
    </div>